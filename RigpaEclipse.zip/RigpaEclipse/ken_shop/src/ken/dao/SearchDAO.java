package ken.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import ken.bean.Item;

public class SearchDAO {
	private Connection connection;
	private PreparedStatement P_statement_selectItems_no_key;
	private PreparedStatement P_statement_selectItems;

	public SearchDAO() throws ClassNotFoundException,SQLException{
		String url = "jdbc:mysql://localhost:3306/latte_station";
		String user  ="root";
		String password = "root";
		connection = DriverManager.getConnection(url,user,password);
		String sql1 = "SELECT * FROM latte_station.item WHERE genre_id = ?";
		String sql2 = "SELECT * FROM latte_station.item WHERE genre_id = ? && (item_name like ? or artist like ?)";
		P_statement_selectItems_no_key = connection.prepareStatement(sql1);
		P_statement_selectItems = connection.prepareStatement(sql2);

		}


	public ArrayList<Item> search_table(String key,String genre) throws SQLException{

		ResultSet rs_items = null;

			if(key != ""){
				P_statement_selectItems.setString(1, genre);
				P_statement_selectItems.setString(2, "%"+ key + "%");
				P_statement_selectItems.setString(3, "%"+ key + "%");
				rs_items= P_statement_selectItems.executeQuery();

             }else{
            	 P_statement_selectItems_no_key.setString(1, genre);
            	 rs_items= P_statement_selectItems_no_key.executeQuery();


             }

			ArrayList<Item> list  = new ArrayList<Item>();

           while(rs_items.next()){
        	   Item item = new  Item();

        	   item.setItemId(rs_items.getInt("item_id"));
        	   item.setItemName(rs_items.getString("item_name"));
        	   item.setItemArtist(rs_items.getString("artist"));
        	   item.setItemprice(rs_items.getInt("price"));
        	   item.setItemImage(rs_items.getString("item_img"));
        	     list.add(item);

           }
           if(rs_items != null){
   			rs_items.close();
   		}

   		if(connection != null) {
   			connection.close();
   		}
   		return list;
	}




}
