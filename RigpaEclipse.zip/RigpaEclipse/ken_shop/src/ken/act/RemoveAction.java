package ken.act;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import ken.bean.Item;

public class RemoveAction extends Action {
    @Override
	public String execute(HttpServletRequest request) throws Exception{
    	String jsp = null;
		HttpSession session = request.getSession(false);
		if(session == null){
			jsp = "/irregular_error.jsp";
		}

		ArrayList<Item> item = (ArrayList<Item>)session.getAttribute("cart");
		String remove_size = request.getParameter("remove");
		item.remove(Integer.parseInt(remove_size));

		jsp = "/cart.jsp";

		return jsp;
	}

}
