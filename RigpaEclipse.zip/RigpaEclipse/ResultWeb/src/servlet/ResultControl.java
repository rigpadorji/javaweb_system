package servlet;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import result.search.ResultSearch;


/**
 * Servlet implementation class ResultControl
 */
@WebServlet("/resultcontrol")
public class ResultControl extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	public  void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());

		request.setCharacterEncoding("UTF-8");

		ServletContext context = request.getServletContext();
	    RequestDispatcher disp = context.getRequestDispatcher("/disp.jsp");
	    disp.forward(request, response);



	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);

	  request.setCharacterEncoding("UTF-8");
	    String jsp = null;
	   String btn = request.getParameter("btn");
	      try{

	    	  if(btn != null && btn.equals("aaa")){
	    		  ResultSearch search = new ResultSearch();
	    		  search.execute(request);
	    		  jsp = "/disp.jsp";

	    	  }else {
	    		 request.setAttribute("errormessage", "wrong acces");
	    		 jsp = "/error.jsp";
	    	  }


	      }catch(SQLException e){
	    	  e.printStackTrace();
	    	  request.setAttribute("errormessage", "something went wrong in jdbc" );
	    	  jsp = "/error.jsp";

	      }catch(Exception e){
	    	  e.printStackTrace();
	    	  request.setAttribute("errormessage", "you had an error");
	    	  jsp = "/error.jsp";
	      }

	      ServletContext context = request.getServletContext();
		    RequestDispatcher disp = context.getRequestDispatcher(jsp);
		    disp.forward(request, response);




	}

}
