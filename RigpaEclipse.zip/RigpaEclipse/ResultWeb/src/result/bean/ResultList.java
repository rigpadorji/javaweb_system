package result.bean;

import java.io.Serializable;

public class ResultList implements Serializable {

	private int studentId;
	private String studentName;
	private String sex;
	private int itMark;
	private int mathMark;
	private int englishMark;
	private int totalMark;
	private String departmentId;
	public int getStudentId() {
		return studentId;
	}
	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public int getItMark() {
		return itMark;
	}
	public void setItMark(int itMark) {
		this.itMark = itMark;
	}
	public int getMathMark() {
		return mathMark;
	}
	public void setMathMark(int mathMark) {
		this.mathMark = mathMark;
	}
	public int getEnglishMark() {
		return englishMark;
	}
	public void setEnglishMark(int englishMark) {
		this.englishMark = englishMark;
	}
	public int getTotalMark() {
		return totalMark;
	}
	public void setTotalMark(int totalMark) {
		this.totalMark = totalMark;
	}
	public String getDepartmentId() {
		return departmentId;
	}
	public void setDepartmentId(String departmentId) {
		this.departmentId = departmentId;
	}

	/*@Override
	public String toString(){
		return "ResultList[stidentid"+ studentId + ",studentname" + studentName + ",sex" + sex+ ",itMark"
				+ itMark + ",mathmark" + mathMark + ",englishMark"+ englishMark+ ",totalmark" + totalMark+
				",departmentid" + departmentId + "]";

	}*/




}
