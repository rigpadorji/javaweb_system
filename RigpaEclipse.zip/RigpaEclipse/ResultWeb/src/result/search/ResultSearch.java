package result.search;


import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import result.bean.ResultList;
import result.dao.ResultDao;

public class ResultSearch {

	public void execute(HttpServletRequest request ) throws Exception{
		ResultDao dao = null;
         String studentid = request.getParameter("stdid");

         try{

        	 if(studentid != null && !studentid.isEmpty()){
        		 dao = new ResultDao();
        		 int id = Integer.parseInt(studentid);

        		 ResultList mylist = dao.getResultById(id);

        		 if(mylist != null){
        			 ArrayList<ResultList> list = new ArrayList<ResultList>();
        			 list.add(mylist);
        			 request.setAttribute("list", list);


        		 }else{
        			 request.setAttribute("meassage", "No id available");

        		 }


        	 }else{
        		 request.setAttribute("message", "please enter the id ");

        	 }


         }finally{

        	 if(dao!= null){
        		 dao.close();

        	 }


         }



	}


}
