package result.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import result.bean.ResultList;

public class ResultDao {
	private Connection connection;

	public ResultDao() throws SQLException{
	    String url = "jdbc:mysql://localhost:3306/marksheet";
	    String user = "root";
	    String password = "root";
	    connection = DriverManager.getConnection(url, user, password);



	}

	public void close(){
		try{
		if(connection != null){
			connection.close();
		}
		}catch(SQLException e){
			e.printStackTrace();
		}
	}


	public ResultList getResultById(int student_id) throws SQLException{
		ResultList rel = null;
		PreparedStatement pstatement = null;
		ResultSet rs  =null;


		try{

		String sql = "SELECT * FROM marksheet.result WHERE student_id = ? ";
		pstatement = connection.prepareStatement(sql);
		pstatement.setInt(1,student_id);
		rs = pstatement.executeQuery();


		if(rs.next()){
			rel = new ResultList();
			rel.setStudentId(rs.getInt("student_id"));
			rel.setStudentName(rs.getString("student_name"));
			rel.setSex(rs.getString("sex"));
			rel.setItMark(rs.getInt("it"));
			rel.setMathMark(rs.getInt("math"));
			rel.setEnglishMark(rs.getInt("english"));
			rel.setTotalMark(rs.getInt("total_mark"));
			rel.setDepartmentId(rs.getString("department_id"));

		}

		rs.close();

		}finally{
			pstatement.close();

		}

		return rel;

	}





}
