package ken.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import ken.bean.Item;

public class SearchDAO {
	private Connection connection;
	private PreparedStatement P_statement_selectItems_no_key;
	private PreparedStatement P_statement_selectItems;

	public SearchDAO() throws ClassNotFoundException,SQLException{
		String url = "jdbc:mysql://localhost:3306/my_database";
		String user  ="root";
		String password = "root";
		connection = DriverManager.getConnection(url,user,password);
		String sql1 = "SELECT * FROM my_database.product WHERE product_id = ?";
		//String sql2 = "SELECT * FROM my_database.product WHERE product_id = ? && product_name like ? ";
		P_statement_selectItems_no_key = connection.prepareStatement(sql1);
		//P_statement_selectItems = connection.prepareStatement(sql2);

		}


	public ArrayList<Item> search_table(String key) throws SQLException{

		ResultSet rs_items = null;

		   if(key != ""){
				P_statement_selectItems_no_key.setInt(1,Integer.parseInt(key));
			   // P_statement_selectItems.setString(2, "%"+ genre + "%");
			    //P_statement_selectItems.setString(3, "%"+ key + "%");
				rs_items= P_statement_selectItems_no_key.executeQuery();
             }/*else{
            	P_statement_selectItems_no_key.setString(1, genre);
            	 rs_items= P_statement_selectItems_no_key.executeQuery();


             }*/

			ArrayList<Item> list  = new ArrayList<Item>();

           while(rs_items.next()){
        	   Item item = new  Item();

        	   item.setProductId(rs_items.getInt("product_id"));
        	   item.setProductName(rs_items.getString("product_name"));
        	  // item.setItemArtist(rs_items.getString("artist"));
        	   item.setPrice(rs_items.getInt("price"));
        	   item.setProductImage(rs_items.getString("product_img"));
        	     list.add(item);

           }
           if(rs_items != null){
   			rs_items.close();
   		}

   		if(connection != null) {
   			connection.close();
   		}
   		return list;
	}





}
