package ken.bean;

import java.io.Serializable;

public class Item implements Serializable {


	private int productId;
	//private String itemArtist;
	private String productName;
	private int price;
	private String productImage;


	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	/*public String getItemArtist() {
		return itemArtist;
	}
	public void setItemArtist(String itemArtist) {
		this.itemArtist = itemArtist;
	}*/
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public String getProductImage() {
		return productImage;
	}
	public void setProductImage(String productImage) {
		this.productImage = productImage;
	}

	@Override
	public String toString(){
		return "Item[productId=" + productId + ", productName=" + productName
				+ ", price=" + price
				+ ", productImage=" + productImage + "]";
	}




}
