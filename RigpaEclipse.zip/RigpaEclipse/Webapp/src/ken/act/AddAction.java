package ken.act;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import ken.bean.Item;

public class AddAction extends Action{
	@Override
	public  String execute(HttpServletRequest request) throws Exception{
		String  jsp = null;
		String id = request.getParameter("id");
		String title = request.getParameter("title");
		//String create = request.getParameter("create");
		String price = request.getParameter("price");
		Item item = new Item();

		     item.setProductId(Integer.parseInt(id));
		     item.setProductName(title);
		     //item.setItemArtist(create);
		     item.setPrice(Integer.parseInt(price));

		     HttpSession session = request.getSession(true);
		     ArrayList<Item> list = (ArrayList<Item>)session.getAttribute("cart");
                 if(list== null){
                	 list = new ArrayList<Item>();
                	 jsp ="/top.jsp";

                 }
                 list.add(item);

                session.setAttribute("cart", list);
		        return jsp;

	}


}
