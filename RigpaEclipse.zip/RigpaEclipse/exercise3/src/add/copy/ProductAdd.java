package add.copy;



import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import bean.ProductBean;
import dao.copy.productDao;

public class ProductAdd {
	public void excecute(HttpServletRequest request) throws Exception{
		productDao dao = null;
        String id = request.getParameter("productid");
        try{
        	if(id != null && !id.isEmpty()){
        		dao = new productDao();
        		ProductBean bean = dao.searchProductById(Integer.parseInt(id));
        		if(bean != null){
        			ArrayList<ProductBean> list = new ArrayList<ProductBean>();
        			list.add(bean);
        			request.setAttribute("list", list);
        		}else{

        			request.setAttribute("message",  "商品がありません");
        		}
        	}else{
        		request.setAttribute("message",  "enter correct id ");
        	}


        }finally{
         if(dao != null){
        	 dao.close();
         }

        }
  }
}
