package exercises3;

public class seatfood {
	public static final String[] item = {"たらばかに","毛ガニ","いか", "うに", "あわび"};
	public static final int[] price = {4000,2500,500,3000,1500};
	public static final String [] image = {"taraba.gif", "ke.gif", "ika.gif", "uni.gif","awabi.gif"};

}
