package exercises3;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
/**
 * Servlet implementation class seatfoodCartServlet
 */
@WebServlet("/cart")
public class seatfoodCartServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		request.setCharacterEncoding("UTF-8");



		HttpSession session = request.getSession(false);
		  ArrayList<String> cart = null;
		  if(session != null){

			  cart = (ArrayList<String>)session.getAttribute("cart");
		  }

		  String message;
		  if(cart != null && !cart.isEmpty()){
			  int total = 0;
			  for(String itemno : cart){
				  int index = Integer.parseInt(itemno);
				  total+= seatfood.price[index];
			  }
			  message = "会計は<strong>￥" + total + "</strong>になります";
		  }else{
			  message ="カートに商品を入力していません";
		  }

		  request.setAttribute("message", message);
		  RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/seatfood_cart.jsp");
            dispatcher.forward(request, response);



	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	public  void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		request.setCharacterEncoding("UTF-8");

		String paramindex = request.getParameter("index");
		HttpSession session = request.getSession(false);
		ArrayList<String> cart = null;
		  if(session != null){

			  cart = (ArrayList<String>)session.getAttribute("cart");
		  }
		  if(cart != null && paramindex != null){
				  int index = Integer.parseInt(paramindex);
				  cart.remove(index);

			  }
		  doGet(request, response);


	}

}
