package exercises3;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import add.copy.ProductAdd;

/**
 * Servlet implementation class SeatfoodFormServlet
 */
@WebServlet("/form")
public class SeatfoodFormServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	public  void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		request.setCharacterEncoding("UTF-8");

			ServletContext context = getServletContext();
			RequestDispatcher dispatcher = context.getRequestDispatcher("/seatfood_form.jsp");
			dispatcher.forward(request, response);



	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	public  void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);

		String btn = request.getParameter("btn");
		String jsp = null;

		try{

			if(btn != null && btn.equals("ProductAdd")){
				ProductAdd en = new ProductAdd();
				en.excecute(request);
				jsp = "/seatfood_form.jsp";

			}else{

				request.setAttribute("errormessage", "wrong acess");
				jsp = "/error.jsp";

			}


		}catch(NumberFormatException e){
			e.printStackTrace();
			request.setAttribute("errormessage", "please enter number");
			jsp = "/error.jsp";


		}catch(SQLException e){
			e.printStackTrace();
			request.setAttribute("errormessage", "JDBCのエラー");
			jsp = "/error.jsp";


		} catch (Exception e) {
			e.printStackTrace();
			request.setAttribute("errormessage", "エラーです");
			jsp = "/error.jsp";

		}

		ServletContext context = getServletContext();

		RequestDispatcher dispatcher = context.getRequestDispatcher(jsp);
		dispatcher.forward(request, response);
	}

}
