package dao.copy;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import bean.ProductBean;


public class productDao {
	private Connection connection;
	private PreparedStatement pstatement;

	public productDao() throws ClassNotFoundException,SQLException{
		String url = "jdbc:mysql://localhost:3306/my_database";
	    String user = "root";
	    String password = "root";
	    connection = DriverManager.getConnection(url,user,password);


	}
	public void close(){
		try{
			if(connection != null){
				connection.close();
			}
		}catch(SQLException e){
			e.printStackTrace();
		}

		}





     public ProductBean searchProductById(int id) throws SQLException{
    	 ProductBean bean = null;
         ResultSet result = null;
         try{
        	 String sql = "SELECT product_name, price, product_img FROM my_database.product WHERE product_id = ?";
     		pstatement = connection.prepareStatement(sql);

         pstatement.setInt(1, id);
         result = pstatement.executeQuery();

		if(result.next()){
		  bean = new ProductBean();
			bean.setProductName(result.getString("product_name"));
			bean.setProductImage(result.getString("product_img"));
			bean.setPrice(result.getInt("price"));


		}
		result.close();
		}finally{
			pstatement.close();
		}

         return bean;
	}












}
