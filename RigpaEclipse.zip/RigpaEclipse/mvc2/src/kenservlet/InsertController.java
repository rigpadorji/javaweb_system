package kenservlet;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kenservice.InsertEmp;
/**
 * Servlet implementation class InsertController
 */
@WebServlet("/insert")
public class InsertController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	public  void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());

		request.setAttribute("message", "検索情報を入力してください。");
		ServletContext context = request.getServletContext();
	    RequestDispatcher dispatcher = context.getRequestDispatcher("/insert.jsp");
	    dispatcher.forward(request, response);



	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	public  void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		request.setCharacterEncoding("UTF-8");
		String searchBtn = request.getParameter("btn");
	     String jsp;

		    try{
		    	if(searchBtn != null && searchBtn.equals("InsertEmp")){
		    		InsertEmp insert = new InsertEmp();
		    		insert.execute(request);
		    		jsp = "/insert.jsp";



		    	}

		    	else{
		    		request.setAttribute("errormessage", "不正アクセサです");
		    		request.setAttribute("backAddress", "insert");
		    		jsp = "/error.jsp";
		    	}



		    }catch(NumberFormatException e){
		         e.printStackTrace();
		         request.setAttribute("errormessage", "年齢には数値を入力してください。");
		         request.setAttribute("backAddress", "insert");
		         jsp= "/error.jsp";

		    }catch(SQLException  e){
		         e.printStackTrace();
		         request.setAttribute("errormessage", "JDBC	のエラーです");
		         request.setAttribute("backAddress", "insert");
		         jsp= "/error.jsp";

		    }catch(Exception e){
		         e.printStackTrace();
		         request.setAttribute("errormessage", "エラーが作成しました。");
		         request.setAttribute("backAddress", "insert");
		         jsp= "/error.jsp";

		    }

		    ServletContext context = request.getServletContext();
		    RequestDispatcher dispatcher = context.getRequestDispatcher(jsp);
		    dispatcher.forward(request, response);




	}


}
