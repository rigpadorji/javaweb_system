
package kenservlet;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kenservice.AgeSearch;
import kenservice.IdSearch;
/**
 * Servlet implementation class Controller
 */
@WebServlet("/controller")
public class Controller extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	public  void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());

		request.setAttribute("message", "検索条件を入力してください。");
		ServletContext context = request.getServletContext();
	    RequestDispatcher dispatcher = context.getRequestDispatcher("/disp.jsp");
	    dispatcher.forward(request, response);



	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	public  void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		request.setCharacterEncoding("UTF-8");
		String searchBtn = request.getParameter("btn");
	     String jsp;

		    try{
		    	if(searchBtn != null && searchBtn.equals("IdSearch")){
		    		IdSearch ids = new IdSearch();
		    		ids.execute(request);
		    		jsp = "/disp.jsp";



		    	}else if(searchBtn != null && searchBtn.equals("AgeSearch")){
		    		AgeSearch ages = new AgeSearch();
		    		ages.execute(request);
		    		jsp = "/disp.jsp";

		    	}

		    	else{
		    		request.setAttribute("errormessage", "不正アクセサです");
		    		request.setAttribute("backAddress", "controller");
		    		jsp = "/error.jsp";
		    	}



		    }catch(NumberFormatException e){
		         e.printStackTrace();
		         request.setAttribute("errormessage", "数値を入力してください。");
		     	request.setAttribute("backAddress", "controller");
		         jsp= "/error.jsp";

		    }catch(SQLException  e){
		         e.printStackTrace();
		         request.setAttribute("errormessage", "JDBC	のエラーです");
		     	request.setAttribute("backAddress", "controller");
		         jsp= "/error.jsp";

		    }catch(Exception e){
		         e.printStackTrace();
		         request.setAttribute("errormessage", "エラーが作成しました。");
		     	request.setAttribute("backAddress", "controller");
		         jsp= "/error.jsp";

		    }

		    ServletContext context = request.getServletContext();
		    RequestDispatcher dispatcher = context.getRequestDispatcher(jsp);
		    dispatcher.forward(request, response);




	}

}
