

package kendao;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import kenmodel.EmpBean;

public class EmpDao {
	 private Connection connection;




	 public EmpDao() throws SQLException{
	    	String url = "jdbc:mysql://localhost:3306/java_web_system";
	    	String user = "root";
	    	String password = "root";
	    	connection = DriverManager.getConnection(url, user, password);

	    }

	  public void close(){
	    	try{
	    		if(connection != null){
	    			connection.close();
	    		}
       }catch(SQLException e){
	    		e.printStackTrace();
       }
	  }


	  public EmpBean getEmpDataById(int empId) throws SQLException{
		EmpBean bean = null;
		PreparedStatement pstatement = null;
		ResultSet rs = null;
		try{
			String sql = "SELECT * FROM employee WHERE employee_id = ?";

			pstatement = connection.prepareStatement(sql);

			pstatement.setInt(1, empId);

			rs = pstatement.executeQuery();
			if(rs.next()){

				bean = new EmpBean();
				bean.setId(rs.getInt("employee_id"));
				bean.setName(rs.getString("employee_name"));
				bean.setAddress(rs.getString("employee_address"));
				bean.setAge(rs.getInt("employee_age"));
				bean.setMail(rs.getString("employee_mail"));
			}

			rs.close();
		}finally{

			pstatement.close();
		}
		return bean;

	}

	  public ArrayList<EmpBean> getEmpDataByAge(int age1, int age2) throws SQLException{
		  ArrayList<EmpBean> empData = null;
		  PreparedStatement pstatement = null;
		  ResultSet rs = null;
		  try{
			  String sql = "SELECT * FROM employee WHERE employee_age BETWEEN ? AND ?";

				pstatement = connection.prepareStatement(sql);

				pstatement.setInt(1, age1);
				pstatement.setInt(2, age2);

				rs = pstatement.executeQuery();
				empData = new ArrayList<EmpBean>();
				while(rs.next()){

					EmpBean bean = new EmpBean();
					bean.setId(rs.getInt("employee_id"));
					bean.setName(rs.getString("employee_name"));
					bean.setAddress(rs.getString("employee_address"));
					bean.setAge(rs.getInt("employee_age"));
					bean.setMail(rs.getString("employee_mail"));
					empData.add(bean);
				}

				rs.close();



		  }finally{
			pstatement.close();


		  }

		  return empData;

	  }


	  public int insertEmpData(EmpBean emp) throws SQLException{
		  int numRow = 0;
		  PreparedStatement pstatement = null;
		  try{
			  connection.setAutoCommit(false);

			  String sql = "INSERT INTO employee(employee_name,employee_address,employee_age,employee_mail) VALUES (?,?,?,?)";

				pstatement = connection.prepareStatement(sql);

				pstatement.setString(1, emp.getName());
				pstatement.setString(2, emp.getAddress());
				pstatement.setInt(3, emp.getAge());
				pstatement.setString(4, emp.getMail());
                 numRow = pstatement.executeUpdate();


		  }finally{
			if(numRow > 0){
				connection.commit();
			}else{
				connection.rollback();
			}
			pstatement.close();


		  }
		  return numRow;


	  }




}
