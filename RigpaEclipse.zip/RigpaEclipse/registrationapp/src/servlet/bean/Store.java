package servlet.bean;

import java.io.Serializable;

public class Store implements Serializable {
	private int registrationNum;
	private String name;
	private int age;
	private String address;
	private String mail;
	private String Country;
	private int secretCode;
	public int getRegistrationNum() {
		return registrationNum;
	}
	public void setRegistrationNum(int registrationNum) {
		this.registrationNum = registrationNum;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getMail() {
		return mail;
	}
	public void setMail(String mail) {
		this.mail = mail;
	}
	public String getCountry() {
		return Country;
	}
	public void setCountry(String country) {
		Country = country;
	}
	public int getSecretCode() {
		return secretCode;
	}
	public void setSecretCode(int secretCode) {
		this.secretCode = secretCode;
	}



}
