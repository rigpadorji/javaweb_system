package servlet.acr;

import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;

import servelt.dao.SearchDao;
import servlet.bean.Store;

public class ActtionSearch {
	public void execute(HttpServletRequest request) throws SQLException{
		SearchDao dao = null ;
	    String rigisNum = request.getParameter("regisNum");
	    String name = request.getParameter("name");
	    String age = request.getParameter("age");
	    String address = request.getParameter("address");
	    String mail = request.getParameter("mail");
	    String country = request.getParameter("country");
	    String code = request.getParameter("code");

	   try{
		   if(rigisNum != null && !rigisNum.isEmpty() &&name != null && !name.isEmpty() &&
			 age != null && !age.isEmpty() && address != null && !address.isEmpty() && mail != null && !mail.isEmpty()&&
			 country != null && !country.isEmpty()&& code != null && !code.isEmpty()){
			    Store store = new Store();
			   store.setRegistrationNum(Integer.parseInt(rigisNum));
			   store.setName(name);
			   store.setAge(Integer.parseInt(age));
			   store.setAddress(address);
			   store.setMail(mail);
			   store.setCountry(country);
			   store.setSecretCode(Integer.parseInt(code));
			   dao = new  SearchDao();
			   int numrow = dao.insertdata(store);
			   if(numrow > 0){
				   request.setAttribute("message", "Registration successfull");
			   }else{
				   request.setAttribute("message", "you could not register");

			   }

		   }else{
			   request.setAttribute("message", "you had some unfill form, please fill all the required form");
		   }


	   }finally{
		   if(dao!= null){
		   dao.close();
		   }

	   }
	}
}
