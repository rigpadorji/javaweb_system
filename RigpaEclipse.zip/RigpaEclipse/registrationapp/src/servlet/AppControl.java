package servlet;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import servlet.acr.ActtionSearch;

/**
 * Servlet implementation class AppControl
 */
@WebServlet("/appcontrol")
public class AppControl extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());

		ServletContext context = request.getServletContext();
		RequestDispatcher dispatcher = context.getRequestDispatcher("/disp.jsp");
		dispatcher.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
	   request.setCharacterEncoding("UTF-8");
	   String jsp  =null;
	   String btn = request.getParameter("btn");
	   try{
		   if(btn != null && btn.equals("insert")){
			   ActtionSearch insert = new ActtionSearch();
			   insert.execute(request);
			   jsp = "/top.jsp";
		   }else {
			   request.setAttribute("error", "you had an error");
			   jsp= "error.jsp";
		   }




	   }catch (NumberFormatException e){
		   e.printStackTrace();
		   request.setAttribute("error", "you had a number format exception error");
		   jsp= "error.jsp";

	   }catch(SQLException e){
		   e.printStackTrace();
		   request.setAttribute("error", "you had error on your database");
		   jsp= "error.jsp";

	   }catch(Exception e){
		   e.printStackTrace();
		   request.setAttribute("error", "you had errpr in your code");
		   jsp= "error.jsp";

	   }




	}

}
