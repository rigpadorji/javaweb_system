package servelt.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import servlet.bean.Store;

public class SearchDao {
	private Connection connection;
	private PreparedStatement pstatement;

	public SearchDao() throws SQLException{
		String url = "jdbc:mysql://localhost:3306/registration";
		String user ="root";
		String password = "root";
		connection = DriverManager.getConnection(url,user,password);


	}


	public void close(){
		try {
		if(connection != null){

				connection.close();

			}
		}catch (SQLException e) {
			e.printStackTrace();
		}
	}



	public int insertdata(Store store ) throws SQLException{
		int numrow =  0;
		try{
			connection.setAutoCommit(false);

			String sql = "INSERT INTO form(registration_num, name, age, address,mail,country,secret_code) VALUES (?,?,?,?,?,?,?)";
			pstatement = connection.prepareStatement(sql);
			pstatement.setInt(1,store.getRegistrationNum());
			pstatement.setString(2, store.getName());
			pstatement.setInt(3, store.getAge());
			pstatement.setString(4, store.getAddress());
			pstatement.setString(5, store.getMail());
			pstatement.setString(6, store.getCountry());
			pstatement.setInt(7, store.getSecretCode());
			numrow = pstatement.executeUpdate();


		}finally{

			if(numrow>0){
				connection.commit();
			}else{
				connection.close();
			}
			pstatement.close();

		}


		return numrow;


	}

}
