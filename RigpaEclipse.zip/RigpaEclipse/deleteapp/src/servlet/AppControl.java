package servlet;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import servlet.act.SearchAct;

/**
 * Servlet implementation class AppControl
 */
@WebServlet("/appcontrol")
public class AppControl extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	public  void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		request.setCharacterEncoding("UTF-8");
		ServletContext context = request.getServletContext();
		RequestDispatcher dispatcher = context.getRequestDispatcher("/disp.jsp");
	     dispatcher.forward(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	public  void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);

		request.setCharacterEncoding("UTF-8");
		String btn = request.getParameter("btn");
		String jsp = null;
		try{
		if(btn != null && btn.equals("search")){
			SearchAct action = new SearchAct();
			action.execute(request);
			jsp= "/disp.jsp";
		}else{
			request.setAttribute("errormessage", "you had a wrong access");
		}

		}catch(SQLException e){
			e.printStackTrace();
			request.setAttribute("errormessage", "you had jdbc error");
			jsp ="/error.jsp";

		}catch(Exception e){
			e.printStackTrace();
			request.setAttribute("errormessage", "you had error");

		}
		ServletContext context = request.getServletContext();
		RequestDispatcher dispatcher = context.getRequestDispatcher(jsp);
	     dispatcher.forward(request,response);


	}

}
