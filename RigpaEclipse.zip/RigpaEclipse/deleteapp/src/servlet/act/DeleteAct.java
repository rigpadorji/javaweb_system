package servlet.act;

import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;

import servlet.dao.SearchDao;

public class DeleteAct {
	public void execut(HttpServletRequest request) throws SQLException{
		SearchDao dao = null;
		String id = request.getParameter("id");
		try{
			if(id != null){
				dao = new SearchDao();
				int del_id = Integer.parseInt(id);
				int numrow = dao.DeleteBYId(del_id);
				if(numrow > 0){

					request.setAttribute("message", "you had delete the database ");
				}else{

					request.setAttribute("message", "you cold not delete ");
				}

			}else{
				request.setAttribute("message", "you had a wrong access");
			}


		}finally{
			if(dao!= null){
				dao.close();
			}

		}


	}

}
