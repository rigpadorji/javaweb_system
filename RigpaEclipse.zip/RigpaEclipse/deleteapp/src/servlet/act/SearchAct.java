package servlet.act;

import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import servlet.dao.SearchDao;
import servlet.model.Item;

public class SearchAct {
	public void execute(HttpServletRequest request) throws SQLException{
		SearchDao dao = null;
		String sex = request.getParameter("sex");
		try{
		if(sex != null && !sex.isEmpty()){
			dao = new SearchDao();
			ArrayList<Item> list = dao.SearchDataBySex(sex);
			if(list.isEmpty()){
				request.setAttribute("message", "no value");

			}else{
				request.setAttribute("list", list);

			}


		}else{
			request.setAttribute("message", "seelct either either male or female");

		}
		}finally{
			if(dao != null){
				dao.close();
			}
		}

	}

}
