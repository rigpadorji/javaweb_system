package servlet.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import servlet.model.Item;

public class SearchDao {
	private Connection connection;
	private PreparedStatement pstatement;

	public SearchDao() throws SQLException{
		String url = "jdbc:mysql://localhost:3306/deletting";
		String user  ="root";
		String password ="root";
		connection = DriverManager.getConnection(url,user,password);


	}
    public void close(){
    	                  try {
    	                       if(connection != null){
    		                          connection.close();

    	                          }

    	                        } catch (SQLException e) {
		                             	e.printStackTrace();
	                                  	}
                         }

    public ArrayList<Item> SearchDataBySex(String sex) throws SQLException{
    	ArrayList<Item>list= null;

    	ResultSet result = null;

    	try{

    	String sql = "SELECT * FROM data WHERE sex = ?";
    	pstatement = connection.prepareStatement(sql);
    	pstatement.setString(1, sex);
    	result = pstatement.executeQuery();
                 list = new ArrayList<Item>();
    	while(result.next()){
    		Item item = new Item();
    		item.setDeleteid(result.getInt("delete_id"));
    		item.setName(result.getString("delete_name"));
    		item.setAge(result.getInt("age"));
    		item.setAddress(result.getString("address"));
    		item.setSex(result.getString("sex"));
            list.add(item);

    	}
    	result.close();


    	}finally{
    		pstatement.close();

    	}

    	return list;
    }


    public int DeleteBYId(int id) throws SQLException{
    	int numrow = 0;
    	try{
    		connection.setAutoCommit(false);
    	 String sql = "DELETE FROM data WHERE delete_id  =?";
    	 pstatement = connection.prepareStatement(sql);
    	 pstatement.setInt(1, id);
    	 numrow = pstatement.executeUpdate();



    	}finally{
    		if(numrow > 0){
    			connection.commit();

    		}else{
    			connection.rollback();
    		}
    		pstatement.close();

    	}
    	return numrow;
    }

}
