package bean.act;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import add.bean.ProBean;

public class ActionAdd extends Action{
	@Override
	public  String execute(HttpServletRequest request) throws Exception{
		String  jsp = null;
		String id = request.getParameter("id");
		String proname = request.getParameter("name");
		String price = request.getParameter("price");

		ProBean item = new ProBean();

		     item.setProductId(Integer.parseInt(id));
		     item.setPrice(Integer.parseInt(price));
		     item.setProductName("proname");

		     HttpSession session = request.getSession(true);
		     ArrayList<ProBean> list = (ArrayList<ProBean>)session.getAttribute("cart");
                 if(list== null){
                	 list = new ArrayList<ProBean>();
                	 jsp ="/top.jsp";

                 }
                 list.add(item);

                session.setAttribute("cart", list);
		        return jsp;

	}

}
