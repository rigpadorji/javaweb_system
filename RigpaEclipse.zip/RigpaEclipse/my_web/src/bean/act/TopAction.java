package bean.act;

import javax.servlet.http.HttpServletRequest;


public class TopAction extends Action {

	@Override
	public  String execute(HttpServletRequest request) throws Exception{

		String jsp = null;
		return jsp;

	}





}
