package bean.act;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import add.bean.ProBean;
import bean.dao.ProductDao;

public class ActionSearch extends Action {

	@Override
	public  String execute(HttpServletRequest request) throws Exception{
		String jsp = null;
		String keyword = request.getParameter("keyword");
		String genre = request.getParameter("genre");
		ProductDao searchdao = new ProductDao();


			ArrayList<ProBean> list = searchdao.search_table(keyword, genre );

			HttpSession session = request.getSession();
			session.setAttribute("table_items", list);
			if(list.size() == 0){
				request.setAttribute("no_item", "");
				jsp = "/top.jsp";

			}
			return jsp;

		}

}
