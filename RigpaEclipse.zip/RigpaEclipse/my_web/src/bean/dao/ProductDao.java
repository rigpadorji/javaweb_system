package bean.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import add.bean.ProBean;

public class ProductDao {

	private Connection connection;
	private PreparedStatement P_statement_selectItems_no_key;
	private PreparedStatement P_statement_selectItems;

	public ProductDao() throws ClassNotFoundException,SQLException{
		String url = "jdbc:mysql://localhost:3306/my_database";
		String user  ="root";
		String password = "root";
		connection = DriverManager.getConnection(url,user,password);
		String sql1 = "SELECT * my_database.product WHERE product_id = ?";
		String sql2 = "SELECT * FROM my_database.product WHERE Product_id && Product_name like ? ";
		P_statement_selectItems_no_key = connection.prepareStatement(sql1);
		P_statement_selectItems = connection.prepareStatement(sql2);

		}


	public ArrayList<ProBean> search_table(String key, String genre) throws SQLException{

		ResultSet rs_items = null;

			if(key != null){

				P_statement_selectItems.setString(1,genre);

				rs_items= P_statement_selectItems.executeQuery();

            }else{
            	P_statement_selectItems.setString(1,genre);
            	P_statement_selectItems.setString(2, "%"+ key + "%");
                rs_items= P_statement_selectItems.executeQuery();
            }

			ArrayList<ProBean> list  = new ArrayList<ProBean>();

           while(rs_items.next()){
        	   ProBean pro = new  ProBean();

        	   pro.setProductId(rs_items.getInt("product_id"));
        	   pro.setProductName(rs_items.getString("product_name"));
        	   pro.setPrice(rs_items.getInt("price"));
        	   pro.setProductImage(rs_items.getString("product_img"));
        	   list.add(pro);

           }
           if(rs_items != null){
   			rs_items.close();
   		}

   		if(connection != null) {
   			connection.close();
   		}
   		return list;
	}


}
