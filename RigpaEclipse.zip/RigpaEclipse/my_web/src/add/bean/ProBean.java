package add.bean;

import java.io.Serializable;

public class ProBean implements Serializable {
	private int productId;
	private String productName;
	private String productImage;
	private int price;

	public int  getProductId() {
		return productId;
	}
	public void setProductId(int  productId) {
		this.productId = productId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getProductImage() {
		return productImage;
	}
	public void setProductImage(String productImage) {
		this.productImage = productImage;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}

	@Override
	public String toString(){
		return "product[productId=" + productId + ", productName=" + productName
				+ ", productprice=" + price + "]";
	}




}
