package servlet;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import web.act.SearchAction;

/**
 * Servlet implementation class WebControl
 */
@WebServlet("/webcontrol")
public class WebControl extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	  public  void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		  request.setCharacterEncoding("UTF-8");
		  ServletContext context = request.getServletContext();
		   RequestDispatcher dispatcher = context.getRequestDispatcher("/disp.jsp");
		   dispatcher.forward(request, response);

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	public  void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		request.setCharacterEncoding("UTF-8");
         String jsp = null;
		String btn = request.getParameter("act");

		try{
			if(btn != null && btn.equals("search")){
				SearchAction search = new SearchAction();
			    search.execute(request,response);
			    jsp = "/disp.jsp";
			}else{
			  request.setAttribute("errormessage", "you had a wrong access");
			   jsp  ="/error.jsp";

			}



		}catch(NumberFormatException e){
			e.printStackTrace();
			request.setAttribute("errormessage", "please enter the numirical value");
			jsp  ="/error.jsp";

		}catch(SQLException e){
			request.setAttribute("errormessage", "problem in your jdbc");
			jsp  ="/error.jsp";
		}catch(Exception e){
			request.setAttribute("errormessage", "you had an error");
			jsp  ="/error.jsp";
		}

	   ServletContext context = request.getServletContext();
	   RequestDispatcher dispatcher = context.getRequestDispatcher(jsp);
	   dispatcher.forward(request, response);





	}

}
