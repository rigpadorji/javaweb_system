package web.act;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import web.bean.BeanList;
import web.dao.ResultDao;

public class SearchAction {
	private ServletContext context;
	private RequestDispatcher dis;


	public void execute(HttpServletRequest request, HttpServletResponse response) throws  ClassNotFoundException, SQLException{


		String dep_id = request.getParameter("dep");
		String std_name = request.getParameter("name");
		ResultDao dao = new ResultDao();
		ArrayList<BeanList> list = dao.SearchResult(dep_id, std_name);

		HttpSession session  = request.getSession();
		session.setAttribute("table", list);
		if(list.size() == 0){
			session.setAttribute("no_item", "");
			dis = context.getRequestDispatcher("/disp.jsp");
			try {
				dis.forward(request, response);
			} catch (ServletException | IOException e) {
				// TODO 自動生成された catch ブロック
				e.printStackTrace();
			}
		}


	}



}
