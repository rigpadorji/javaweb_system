package web.act;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import web.bean.BeanList;



public class AddSearch {

	public  String execute(HttpServletRequest request) throws Exception{
		String  jsp = null;
		String id = request.getParameter("id");
		String name = request.getParameter("name");
		String sex = request.getParameter("sex");
		String it = request.getParameter("it");
		String math = request.getParameter("math");
		String eng = request.getParameter("eng");
		String total = request.getParameter("total");
		String std_id = request.getParameter("stdid");
		 BeanList item = new BeanList();

		     item.setStudentId(Integer.parseInt(id));
		     item.setStudentName(name);
		     item.setSex(sex);
		     item.setItMark(Integer.parseInt(it));
		     item.setMathMark(Integer.parseInt(math));
		     item.setEnglishMark(Integer.parseInt(eng));
		     item.setTotalMark(Integer.parseInt(total));
		     item.setDepartmentId(std_id);



		     HttpSession session = request.getSession(true);
		     ArrayList<BeanList> list = (ArrayList<BeanList>)session.getAttribute("cart");
                 if(list== null){
                	 list = new ArrayList<BeanList>();
                	 jsp ="/top.jsp";

                 }
                 list.add(item);

                session.setAttribute("cart", list);
		        return jsp;

	}

}
