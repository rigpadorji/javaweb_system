package web.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import web.bean.BeanList;

public class ResultDao {
	 private Connection connection;
	 private PreparedStatement pstatement_name;
	 private PreparedStatement pstatement_dep;


	public ResultDao() throws  ClassNotFoundException, SQLException{
		String url = "jdbc:mysql://localhost:3306/marksheet";
		String user = "root";
		String password = "root";
		connection = DriverManager.getConnection(url,user, password);

		String sql1 = "SELECT * FROM  result WHERE department_id = ?";
		String sql2 = "SELECT * FROM  result WHERE department_id = ? AND student_name like ?";
		pstatement_dep = connection.prepareStatement(sql1);
		pstatement_name = connection.prepareStatement(sql2);

	}


	public ArrayList<BeanList> SearchResult(String id, String name) throws SQLException{

		ResultSet rs = null;
	  if(id != ""){
			pstatement_dep.setString(1,id);
			pstatement_name.setString(2, "%" + name + "%");
			rs =pstatement_dep.executeQuery();
			rs =pstatement_name.executeQuery();

		}else{
			pstatement_dep.setString(1,id);
			rs=pstatement_dep.executeQuery();
		}

      ArrayList<BeanList> list = new ArrayList<BeanList>();
         while(rs.next()){
        	BeanList  bean = new BeanList();
        	 bean.setStudentId(rs.getInt("student_id"));
        	 bean.setStudentName(rs.getString("student_name"));
        	 bean.setSex(rs.getString("sex"));
        	 bean.setItMark(rs.getInt("it"));
        	 bean.setMathMark(rs.getInt("math"));
        	 bean.setEnglishMark(rs.getInt("english"));
        	 bean.setTotalMark(rs.getInt("total_mark"));
        	 bean.setDepartmentId(rs.getString("depatment_id"));
        	 list.add(bean);

         }
         if(rs != null){
        	 rs.close();
         }
         if(connection != null){
        	 connection.close();
         }




    return list;

	}


}
