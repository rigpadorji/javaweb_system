package servlet.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import servlet.model.Storage;

public class InsertDao {
	private Connection connection;
	private PreparedStatement pstatement;


	public InsertDao() throws SQLException{
		String url = "jdbc:mysql://localhost:3306/register";
		String user = "root";
		String password = "root";
		connection = DriverManager.getConnection(url, user,password);


	}
	public void close(){
		try {
		if(connection!= null){

				connection.close();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		}




	public int CreateAccount(Storage store) throws SQLException{
		int numrow = 0;
		try{
			connection.setAutoCommit(false);
			String sql = "INSERT INTO userform(username, firstname,lastname,password, mail_address,date_of_birth, gender, country)Values(?,?,?,?,?,?,?,?)";
			pstatement = connection.prepareStatement(sql);
			pstatement.setString(1, store.getUseerName());
			pstatement.setString(2, store.getFirstName());
			pstatement.setString(3, store.getLastName());
			pstatement.setString(4, store.getPassword());
			pstatement.setString(5, store.getMail());
			pstatement.setDate(6, new java.sql.Date(store.getDate().getTime()));
			//pstatement.setInt(6, store.getBirthDate());
			pstatement.setString(7, store.getGender());
			pstatement.setString(8, store.getCountry());


		numrow = pstatement.executeUpdate();


		}finally{
			if(numrow > 0){
			   connection.commit();
			}else{
				connection.rollback();
			}
			pstatement.close();

		}



		return numrow;
	}

}
