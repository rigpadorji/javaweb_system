package servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class LoginControl
 */
@WebServlet("/logincontrol")
public class LoginControl extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		request.setCharacterEncoding("UTF-8");
		ServletContext context = request.getServletContext();
		RequestDispatcher dispatcher = context.getRequestDispatcher("/index.jsp");
		dispatcher.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);

		request.setCharacterEncoding("UTF-8");
		 Connection connection;
		 String jsp = null;
		  String username = request.getParameter("uname");
		  String password = request.getParameter("psw");

		  try{
		  if(username!= null && !username.isEmpty()&&password!= null && !password.isEmpty()){

			  Class.forName("com.mysql.jdbc.Driver");
			  connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/register","root","root");
			  String sql = "SELECT * FROM userform WHERE username = ? and password = ?";
			  PreparedStatement pstatement = connection.prepareStatement(sql);
			  pstatement.setString(1, username);
			  pstatement.setString(2, password);
			  ResultSet result = pstatement.executeQuery();
			  HttpSession session = request.getSession();
			  session.setAttribute("username", username);
			  if(result.next()){
				  jsp ="/top.jsp";
			  }else{
				  request.setAttribute("errormessage", "you had either wrong password or username");
				  jsp= "/error.jsp";

			  }
		  }else{
			  request.setAttribute("errormessage", "please enter username and password");
			  jsp= "/error.jsp";

		  }

		  }catch(ClassNotFoundException e){
			  e.printStackTrace();
			  request.setAttribute("errormessage", "you had class not found error");
			  jsp= "/error.jsp";

		  }catch(SQLException e){
			  e.printStackTrace();
			  request.setAttribute("errormessage", "error on yur database");
			  jsp= "/error.jsp";

		  }catch(Exception e){
			  e.printStackTrace();
			  request.setAttribute("errormessage", "you had a error");
			  jsp= "/error.jsp";

		  }






		ServletContext context = request.getServletContext();
		RequestDispatcher dispatcher = context.getRequestDispatcher(jsp);
		dispatcher.forward(request, response);
	}

}
