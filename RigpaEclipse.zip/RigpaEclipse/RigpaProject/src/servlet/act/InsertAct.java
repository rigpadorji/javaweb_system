package servlet.act;

import java.text.DateFormat;
import java.text.SimpleDateFormat;

import javax.servlet.http.HttpServletRequest;

import servlet.dao.InsertDao;
import servlet.model.Storage;

public class InsertAct {
	public void execute(HttpServletRequest request ) throws Exception{
		DateFormat form = new SimpleDateFormat("yyyy/MM/dd");
		InsertDao dao = null;
		String jsp;
		String firstname = request.getParameter("firstname");
		String lastname = request.getParameter("lastname");
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		String mail = request.getParameter("mail");
		String birth = request.getParameter("birth");
		String gender = request.getParameter("gender");
		String country = request.getParameter("country");
		try{

			if(firstname != null && !firstname.isEmpty() &&lastname != null && !lastname.isEmpty() &&
					username != null && !username.isEmpty() && password != null && !password.isEmpty() && mail != null && !mail.isEmpty()&& gender != null && !gender.isEmpty()&&
					 country != null && !country.isEmpty()){
				    Storage store = new Storage();
				    store.setFirstName(firstname);
				    store.setLastName(lastname);
				    store.setUseerName(username);
				    store.setPassword(password);
				    store.setMail(mail);
				    store.setDate(form.parse(birth));
				    //store.setBirthDate(Integer.parseInt(birth));
				    store.setGender(gender);
				    store.setCountry(country);
				    dao = new InsertDao();
				   int numrow = dao.CreateAccount(store);
				   if(numrow > 0){
					   request.setAttribute("message", "you had successfully create account ");

				   }else{
					   request.setAttribute("message", "try again from the beginning");
				   }

			}else{
				request.setAttribute("message", "you had left unfill, please fill it all");

			}
			}
			finally{
				if(dao!= null){
					dao.close();
				}

		}



	}

}
