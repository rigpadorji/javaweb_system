package ken.act;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import ken.bean.Item;
import ken.dao.SearchDAO;



public class SearchAction extends Action{
	@Override
	public  String execute(HttpServletRequest request) throws Exception{
		String jsp = null;
		String dep = request.getParameter("dep");
		String name = request.getParameter("name");
		SearchDAO searchdao = new SearchDAO();


			ArrayList<Item> list = searchdao.search_table(dep, name);

			HttpSession session = request.getSession();
			session.setAttribute("table_items", list);
			if(list.size() == 0){
				request.setAttribute("no_item", "");
				jsp = "/top.jsp";

			}
			return jsp;

		}






}
