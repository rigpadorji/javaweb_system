package ken.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import ken.bean.Item;

public class SearchDAO {
	private Connection connection;
	private PreparedStatement P_statement_selectItems_no_key;
	private PreparedStatement P_statement_selectItems;

	public SearchDAO() throws ClassNotFoundException,SQLException{
		String url = "jdbc:mysql://localhost:3306/marksheet";
		String user  ="root";
		String password = "root";
		connection = DriverManager.getConnection(url,user,password);
		String sql1 = "SELECT * FROM marksheet.result WHERE department_id = ?";
		String sql2 = "SELECT * FROM marksheet.result WHERE department_id = ? && student_name like ?";
		P_statement_selectItems_no_key = connection.prepareStatement(sql1);
		P_statement_selectItems = connection.prepareStatement(sql2);

		}


	public ArrayList<Item> search_table(String dep,String name) throws SQLException{

		ResultSet rs_items = null;

			if(dep != ""){
				P_statement_selectItems.setString(1, dep);
				P_statement_selectItems.setString(2, "%"+ name + "%");
				rs_items= P_statement_selectItems.executeQuery();

             }else{
            	 P_statement_selectItems_no_key.setString(1, dep);
            	 rs_items= P_statement_selectItems_no_key.executeQuery();


             }

			ArrayList<Item> list  = new ArrayList<Item>();

           while(rs_items.next()){
        	   Item item = new  Item();

        	   item.setStudentId(rs_items.getInt("student_id"));
        	   item.setStudentName(rs_items.getString("student_name"));
        	   item.setSex(rs_items.getString("sex"));
        	   item.setItMark(rs_items.getInt("it"));
        	   item.setMathMark(rs_items.getInt("math"));
        	   item.setEnglishMark(rs_items.getInt("english"));
        	   item.setTotalMark(rs_items.getInt("total_mark"));
        	   item.setDepartmentId(rs_items.getString("department_id"));
          	   list.add(item );

           }
           if(rs_items != null){
   			rs_items.close();
   		}

   		if(connection != null) {
   			connection.close();
   		}
   		return list;
	}




}
