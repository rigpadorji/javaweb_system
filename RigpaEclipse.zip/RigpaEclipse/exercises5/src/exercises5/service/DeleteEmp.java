package exercises5.service;

import javax.servlet.http.HttpServletRequest;

import exercises5.dao.EmpDao;

public class DeleteEmp {
	public void execute(HttpServletRequest request) throws Exception {
		EmpDao dao = null;
		String empId = request.getParameter("empId");
		try {
			if (empId != null) {
				dao= new EmpDao();
				int id = Integer.parseInt(empId);
				int numRow = dao.deleteEmpData(id);
				if (numRow > 0) {
					request.setAttribute("completemessage", "正業が削除できました");
				} else {
					request.setAttribute("completemessage", "正業が削除できませんでした");
				}
			} else {
				request.setAttribute("confirmmessage", "不正なアクセサです");
			}
		} finally {
			if (dao != null) {
				dao.close();
			}
		}
	}

}
