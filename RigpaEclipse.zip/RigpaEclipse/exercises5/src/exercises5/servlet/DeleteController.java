package exercises5.servlet;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import exercises5.service.DeleteEmp;

/**
 * Servlet implementation class DeleteController
 */
@WebServlet("/delete")
public class DeleteController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		request.setCharacterEncoding("UTF-8");
		String empId = request.getParameter("empId");
		String jsp;
		try {
			int id = Integer.parseInt(empId);
			request.setAttribute("confirmmessage", "ID "+ empId + "削除しました");
				jsp = "/delete.jsp";
		} catch (NumberFormatException e) {
			request.setAttribute("errormessage", "不正な操作です");
			jsp = "/error.jsp";
		}
		ServletContext context = getServletContext();
		RequestDispatcher rd = context.getRequestDispatcher(jsp);
		rd.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		request.setCharacterEncoding("UTF-8");
		String jsp;

		try {
			DeleteEmp delete = new DeleteEmp();
			delete.execute(request);
			jsp="/delete.jsp";
		} catch (NumberFormatException e) {

			request.setAttribute("errormessage", "削除するIDが不正でした。");
			jsp = "/error.jsp";
		} catch (SQLException e) {
			e.printStackTrace();
			request.setAttribute("errormessage", "JDBCのエラーです");
			jsp = "/error.jsp";
		} catch (Exception e) {
			e.printStackTrace();
			request.setAttribute("errormessage", "エラーが発生しました");
			jsp = "/error.jsp";
		}

		ServletContext context = getServletContext();
		RequestDispatcher rd = context.getRequestDispatcher(jsp);
		rd.forward(request, response);
	}
}
