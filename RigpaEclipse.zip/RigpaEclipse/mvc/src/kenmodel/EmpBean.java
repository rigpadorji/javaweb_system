package kenmodel;

public class EmpBean {

}
