package kendao;

public class EmpDao {

}
