package ken.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import ken.bean.Item;

public class SearchDAO {
	//検索に使用するDB接続クラス

	private Connection connection;
	private PreparedStatement p_statement_selectItems_no_key;
	private PreparedStatement p_statement_selectItems;

	//データベース「latte_station」の接続を行う
	public SearchDAO() throws ClassNotFoundException, SQLException{
		String url = "jdbc:mysql://localhost:3306/latte_station";
		String user = "root";
		String password = "root";
		connection = DriverManager.getConnection(url, user, password);

		//INパラメータの設定
		String sql1 = "SELECT * FROM item WHERE genre_id=?";
		String sql2 = "SELECT * FROM item WHERE genre_id=? and (item_name like ? or artist like ?)";

		p_statement_selectItems_no_key = connection.prepareStatement(sql1);
		p_statement_selectItems = connection.prepareStatement(sql2);

	}

	public ArrayList<Item> search_table(String key, String genre) throws SQLException{
		ResultSet rs_items = null;

		//キーワードが空文字ではない場合
		if(key != ""){
			p_statement_selectItems.setString(1, genre);
			p_statement_selectItems.setString(2, "%" + key +"%");
			p_statement_selectItems.setString(3, "%" + key +"%");
			rs_items = p_statement_selectItems.executeQuery();
		} else {
			p_statement_selectItems_no_key.setString(1, genre);
			rs_items = p_statement_selectItems_no_key.executeQuery();
		}

		ArrayList<Item> list = new ArrayList<Item>();

		while(rs_items.next()){
			Item item = new Item();
			item.setItemID(rs_items.getInt("item_id"));
			item.setItemName(rs_items.getString("item_name"));
			item.setItemArtist(rs_items.getString("artist"));
			item.setItemPrice(rs_items.getInt("price"));
			item.setItemImage(rs_items.getString("item_img"));
			list.add(item);

			//System.out.println(rs_items.getInt("item_id"));	//デバッグ用　コンソールで確認
		}

		if(rs_items != null){
			rs_items.close();
		}

		if(connection != null) {
			connection.close();
		}
		return list;
	}
}
