package ken.act;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import ken.bean.Item;

public class AddAction extends Action{
	//買い物カゴに商品を追加する機能を持つクラス

	@Override
	public String execute(HttpServletRequest request) throws Exception {
		String id  = request.getParameter("id");
		String title = request.getParameter("title");
		String create = request.getParameter("create");
		String price = request.getParameter("price");

		Item item = new Item();
		item.setItemID(Integer.parseInt(id));
		item.setItemName(title);
		item.setItemArtist(create);
		item.setItemPrice(Integer.parseInt(price));

		HttpSession session = request.getSession(true);
		ArrayList<Item> list = (ArrayList<Item>)session.getAttribute("cart");

		if(list == null){
			list = new ArrayList<Item>();
		}

		list.add(item);

		session.setAttribute("cart", list);

		return "/top.jsp";

	}

}
