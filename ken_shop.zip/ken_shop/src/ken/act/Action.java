package ken.act;

import javax.servlet.http.HttpServletRequest;

public abstract class Action {
	//リクエストごとの機能を持つクラスの親クラス
	//具体的な処理を記述するクラスはすべてこのクラスを継承し、
	//各機能はexecute()メソッドをオーバーライドして記述する

	//抽象メソッド
	abstract public String execute(HttpServletRequest request) throws Exception;
}