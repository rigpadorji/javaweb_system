package ken.act;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import ken.bean.Item;
import ken.dao.SearchDAO;

public class SearchAction extends Action{
	//検索機能を持つクラス

	@Override
	public String execute(HttpServletRequest request) throws Exception {

		String keyword = request.getParameter("keyword");
		String genre = request.getParameter("genre");

		SearchDAO searchDao = new SearchDAO();
		ArrayList<Item> list = searchDao.search_table(keyword, genre);

		HttpSession session = request.getSession();
		session.setAttribute("table_items", list);

		//ArrayListの要素数が
		if(list.size() == 0){
			request.setAttribute("no_item", "");
		}
		return "/top.jsp";
	}
}
