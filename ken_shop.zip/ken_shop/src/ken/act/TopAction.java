package ken.act;

import javax.servlet.http.HttpServletRequest;

public class TopAction extends Action{
	//検索画面にする機能を持つクラス

	@Override
	public String execute(HttpServletRequest request) throws Exception {
		return "/top.jsp";
	}

}
