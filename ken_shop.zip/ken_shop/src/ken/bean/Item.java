package ken.bean;

import java.io.Serializable;

public class Item implements Serializable {
	//商品情報を保持するBeanクラス

	private int itemID;
	private String itemName;
	private String itemArtist;
	private int itemPrice;
	private String itemImage;

	public void setItemID(int itemID) {
		this.itemID = itemID;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public void setItemArtist(String itemArtist) {
		this.itemArtist = itemArtist;
	}

	public void setItemPrice(int itemPrice) {
		this.itemPrice = itemPrice;
	}

	public void setItemImage(String itemImage) {
		this.itemImage = itemImage;
	}

	public int getItemID() {
		return itemID;
	}

	public String getItemName() {
		return itemName;
	}

	public String getItemArtist() {
		return itemArtist;
	}

	public int getItemPrice() {
		return itemPrice;
	}

	public String getItemImage() {
		return itemImage;
	}

	//文字列
	@Override
	public String toString(){
		return "Item[itemID=" + itemID + ", itemName=" + itemName
				+ ",itemArtist=" + itemArtist +", itemPrice=" + itemPrice
				+ ", itemImage=" + itemImage + "]";
	}


}
